class Node:

    def __init__(self, id, type, x, y, remain_time, material_state, product_state):
        self.id = id
        self.type = type
        self.x = x
        self.y = y
        self.remain_time = remain_time
        self.material_state = material_state
        self.product_state = product_state
